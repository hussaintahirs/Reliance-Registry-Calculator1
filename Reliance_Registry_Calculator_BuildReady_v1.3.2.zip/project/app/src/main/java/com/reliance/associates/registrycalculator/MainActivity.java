package com.reliance.associates.registrycalculator;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends Activity {
    private WebView webView;

    private static final int REPORT_WIDTH = 1080;
    private static final int REPORT_HEIGHT = 2320;
    private static final int GREEN = Color.rgb(0, 107, 55);
    private static final int GREEN_BRIGHT = Color.rgb(7, 148, 71);
    private static final int LIGHT_GREEN = Color.rgb(234, 248, 239);
    private static final int SOFT = Color.rgb(247, 250, 248);
    private static final int INK = Color.rgb(21, 51, 41);
    private static final int MUTED = Color.rgb(95, 115, 106);
    private static final String BUSINESS_PHONE = "+92 300-9749221";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);

        webView.addJavascriptInterface(new ShareBridge(), "AndroidShare");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(MainActivity.this, "No browser available to open this link.", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                return false;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(MainActivity.this, "No browser available to open this link.", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                return false;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private Uri uriForFile(File file) {
        return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
    }

    private Paint paint(float size, int color, boolean bold) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        p.setTextSize(size);
        p.setColor(color);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL));
        return p;
    }

    private Paint centeredPaint(float size, int color, boolean bold) {
        Paint p = paint(size, color, bold);
        p.setTextAlign(Paint.Align.CENTER);
        return p;
    }

    private Bitmap loadLogo() {
        try (InputStream in = getAssets().open("reliance_logo.png")) {
            return BitmapFactory.decodeStream(in);
        } catch (IOException e) {
            return null;
        }
    }

    private String value(JSONObject obj, String key) {
        String v = obj.optString(key, "-");
        return v == null || v.trim().isEmpty() ? "-" : v.trim();
    }

    private boolean containsUrdu(String text) {
        if (text == null) return false;
        for (int i = 0; i < text.length(); ) {
            int cp = text.codePointAt(i);
            i += Character.charCount(cp);
            if ((cp >= 0x0600 && cp <= 0x06FF) ||
                    (cp >= 0x0750 && cp <= 0x077F) ||
                    (cp >= 0x08A0 && cp <= 0x08FF)) {
                return true;
            }
        }
        return false;
    }

    private Typeface bundledUrduTypeface;

    private Typeface urduTypeface() {
        // The Urdu report font is bundled inside the APK, so the customer's
        // phone does not need to have Jameel Noori installed.
        if (bundledUrduTypeface == null) {
            try {
                bundledUrduTypeface = Typeface.createFromAsset(getAssets(), "fonts/JameelNooriKasheeda.ttf");
            } catch (Throwable ignored) {
                bundledUrduTypeface = Typeface.create("serif", Typeface.NORMAL);
            }
        }
        return bundledUrduTypeface;
    }

    private Paint fitRightAlignedPaint(String text, float startSize, float minSize, float maxWidth, int color, boolean bold, boolean urdu) {
        Paint p = paint(startSize, color, bold);
        if (urdu) p.setTypeface(urduTypeface());
        p.setTextAlign(Paint.Align.RIGHT);
        while (p.getTextSize() > minSize && p.measureText(text) > maxWidth) {
            p.setTextSize(p.getTextSize() - 1f);
        }
        return p;
    }

    private float drawSectionTitle(Canvas canvas, String title, float y) {
        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setColor(LIGHT_GREEN);
        canvas.drawRoundRect(new RectF(60, y, 1020, y + 56), 18, 18, bg);
        canvas.drawText(title, 84, y + 38, paint(29, GREEN, true));
        return y + 82;
    }

    private float drawRow(Canvas canvas, String label, String val, float y, boolean emphasis) {
        if (emphasis) {
            Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
            bg.setColor(LIGHT_GREEN);
            canvas.drawRoundRect(new RectF(70, y - 33, 1010, y + 18), 13, 13, bg);
        }
        Paint lp = paint(emphasis ? 26 : 24, INK, emphasis);
        Paint vp = paint(emphasis ? 27 : 24, emphasis ? GREEN : INK, emphasis);
        vp.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText(label, 82, y, lp);
        canvas.drawText(val, 998, y, vp);
        return y + (emphasis ? 58 : 43);
    }

    private float drawCustomerRow(Canvas canvas, String label, String val, float y, boolean nameRow) {
        canvas.drawText(label, 82, y, paint(23, MUTED, true));
        boolean urdu = nameRow && containsUrdu(val);
        Paint vp = fitRightAlignedPaint(val, urdu ? 39 : 27, 23, 650, INK, nameRow && !urdu, urdu);
        canvas.drawText(val, 998, y, vp);
        return y + (urdu ? 64 : 45);
    }

    private float drawWrappedCentered(Canvas canvas, String text, float centerX, float y, float maxWidth, Paint p, float lineHeight) {
        String[] words = text.split("\\s+");
        StringBuilder line = new StringBuilder();
        p.setTextAlign(Paint.Align.CENTER);
        for (String word : words) {
            String test = line.length() == 0 ? word : line + " " + word;
            if (p.measureText(test) > maxWidth && line.length() > 0) {
                canvas.drawText(line.toString(), centerX, y, p);
                y += lineHeight;
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(test);
            }
        }
        if (line.length() > 0) {
            canvas.drawText(line.toString(), centerX, y, p);
            y += lineHeight;
        }
        return y;
    }

    private Bitmap buildReportBitmap(String reportJson) throws Exception {
        JSONObject o = new JSONObject(reportJson);
        Bitmap bitmap = Bitmap.createBitmap(REPORT_WIDTH, REPORT_HEIGHT, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(Color.WHITE);

        Bitmap logo = loadLogo();
        if (logo != null) {
            Paint wm = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            wm.setAlpha(10);
            float wmW = 610f;
            float wmH = wmW * logo.getHeight() / (float) logo.getWidth();
            canvas.drawBitmap(logo, null,
                    new RectF((REPORT_WIDTH - wmW) / 2f, 770, (REPORT_WIDTH + wmW) / 2f, 770 + wmH), wm);
        }

        Paint header = new Paint(Paint.ANTI_ALIAS_FLAG);
        header.setShader(new LinearGradient(0, 0, REPORT_WIDTH, 340, GREEN, GREEN_BRIGHT, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, REPORT_WIDTH, 340, header);

        if (logo != null) {
            Paint white = new Paint(Paint.ANTI_ALIAS_FLAG);
            white.setColor(Color.WHITE);
            canvas.drawRoundRect(new RectF(445, 24, 635, 192), 24, 24, white);
            float maxW = 150f, maxH = 145f;
            float scale = Math.min(maxW / logo.getWidth(), maxH / logo.getHeight());
            float w = logo.getWidth() * scale;
            float h = logo.getHeight() * scale;
            canvas.drawBitmap(logo, null,
                    new RectF(540 - w / 2f, 108 - h / 2f, 540 + w / 2f, 108 + h / 2f),
                    new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
        }

        canvas.drawText("RELIANCE ASSOCIATES", 540, 238, centeredPaint(46, Color.WHITE, true));
        canvas.drawText("Property Registry Expense Estimate", 540, 286, centeredPaint(31, Color.WHITE, true));
        canvas.drawText("Financial Year 2026 - 2027", 540, 322, centeredPaint(22, Color.WHITE, false));

        float y = 382;

        y = drawSectionTitle(canvas, "Customer Details", y);
        Paint customerBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        customerBg.setColor(SOFT);
        canvas.drawRoundRect(new RectF(60, y - 18, 1020, y + 145), 18, 18, customerBg);
        y += 18;
        y = drawCustomerRow(canvas, "Customer Name", value(o, "customerName"), y, true);
        y = drawCustomerRow(canvas, "Customer Phone", value(o, "customerPhone"), y, false);
        y = drawCustomerRow(canvas, "Report Date", value(o, "reportDate"), y, false) + 12;

        y = drawSectionTitle(canvas, "Property / DC Valuation", y);
        y = drawRow(canvas, "Land DC Value", value(o, "landDc"), y, false);
        y = drawRow(canvas, "Covered Area", value(o, "coveredArea"), y, false);
        y = drawRow(canvas, "Building DC Rate / sq ft", value(o, "buildingRate"), y, false);
        y = drawRow(canvas, "Building DC Value", value(o, "buildingValue"), y, false);
        y = drawRow(canvas, "Total DC Value", value(o, "totalDc"), y, true);
        y = drawRow(canvas, "Map Approval", value(o, "mapApproval"), y, false) + 12;

        y = drawSectionTitle(canvas, "Buyer Expenses", y);
        y = drawRow(canvas, "Buyer Filer?", value(o, "buyerFiler"), y, false);
        y = drawRow(canvas, "Stamp Duty (1%)", value(o, "stamp"), y, false);
        y = drawRow(canvas, "PLRA Registration", value(o, "plra"), y, false);
        y = drawRow(canvas, "TMA Tax (1%)", value(o, "tma"), y, false);
        y = drawRow(canvas, "Registration Fee", value(o, "registration"), y, false);
        y = drawRow(canvas, "236K Buyer Tax " + value(o, "buyerRate"), value(o, "buyerTax"), y, false);
        y = drawRow(canvas, "Other Buyer Charges", value(o, "otherBuyer"), y, false);
        y = drawRow(canvas, "TOTAL BUYER EXPENSE", value(o, "buyerTotal"), y, true) + 12;

        y = drawSectionTitle(canvas, "Seller Expenses", y);
        y = drawRow(canvas, "Seller Filer?", value(o, "sellerFiler"), y, false);
        y = drawRow(canvas, "236C Seller Tax " + value(o, "sellerRate"), value(o, "sellerTax"), y, false);
        y = drawRow(canvas, "Map Penalty", value(o, "mapPenalty"), y, false);
        y = drawRow(canvas, "Other Seller Charges", value(o, "otherSeller"), y, false);
        y = drawRow(canvas, "TOTAL SELLER EXPENSE", value(o, "sellerTotal"), y, true) + 18;

        Paint totalBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        totalBg.setColor(GREEN);
        canvas.drawRoundRect(new RectF(60, y, 1020, y + 166), 22, 22, totalBg);
        canvas.drawText("Buyer Total", 100, y + 42, paint(21, Color.WHITE, false));
        canvas.drawText(value(o, "buyerTotal"), 100, y + 78, paint(28, Color.WHITE, true));
        Paint sellerLabel = paint(21, Color.WHITE, false);
        sellerLabel.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText("Seller Total", 980, y + 42, sellerLabel);
        Paint sellerValue = paint(28, Color.WHITE, true);
        sellerValue.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText(value(o, "sellerTotal"), 980, y + 78, sellerValue);
        canvas.drawText(value(o, "grandTotal"), 540, y + 119, centeredPaint(40, Color.WHITE, true));
        canvas.drawText("TOTAL ESTIMATED REGISTRY EXPENSES", 540, y + 151, centeredPaint(21, Color.WHITE, true));
        y += 208;

        canvas.drawText("Reliance Associates  |  Contact: " + BUSINESS_PHONE, 540, y,
                centeredPaint(25, GREEN, true));
        canvas.drawText("Your Trusted Property & Documentation Partner", 540, y + 36,
                centeredPaint(21, INK, false));
        y += 82;

        String disclaimer = "Disclaimer: This calculation is for informational purposes only for the Financial Year 2026 - 2027. Reliance Associates assumes no responsibility for any discrepancies or changes in government tax rates.";
        drawWrappedCentered(canvas, disclaimer, 540, y, 930, paint(18, MUTED, false), 27);

        return bitmap;
    }

    private File writePng(Bitmap bitmap) throws IOException {
        File file = new File(getCacheDir(), "Reliance_Registry_Calculation.png");
        try (FileOutputStream out = new FileOutputStream(file)) {
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                throw new IOException("PNG compression failed");
            }
        }
        return file;
    }

    private File writePdf(Bitmap bitmap) throws IOException {
        File file = new File(getCacheDir(), "Reliance_Registry_Calculation.pdf");
        PdfDocument document = new PdfDocument();
        try {
            int pageWidth = 595;
            int pageHeight = 842;
            int margin = 20;
            PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create();
            PdfDocument.Page page = document.startPage(pageInfo);
            Canvas canvas = page.getCanvas();
            canvas.drawColor(Color.WHITE);
            float scale = Math.min((pageWidth - margin * 2f) / bitmap.getWidth(), (pageHeight - margin * 2f) / bitmap.getHeight());
            float w = bitmap.getWidth() * scale;
            float h = bitmap.getHeight() * scale;
            float left = (pageWidth - w) / 2f;
            float top = (pageHeight - h) / 2f;
            canvas.drawBitmap(bitmap, null, new RectF(left, top, left + w, top + h),
                    new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
            document.finishPage(page);
            try (FileOutputStream out = new FileOutputStream(file)) {
                document.writeTo(out);
            }
        } finally {
            document.close();
        }
        return file;
    }

    private void shareGeneral(Uri uri, String mimeType, String title, String text) {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType(mimeType);
        share.putExtra(Intent.EXTRA_STREAM, uri);
        if (text != null) share.putExtra(Intent.EXTRA_TEXT, text);
        share.setClipData(ClipData.newRawUri("Reliance Registry Calculation", uri));
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(share, title));
    }

    private boolean tryWhatsAppPackage(Uri uri, String caption, String phoneDigits, String packageName) {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("image/png");
        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.putExtra(Intent.EXTRA_TEXT, caption);
        share.putExtra("jid", phoneDigits + "@s.whatsapp.net");
        share.setClipData(ClipData.newRawUri("Reliance Registry Calculation", uri));
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        share.setPackage(packageName);
        try {
            startActivity(share);
            return true;
        } catch (ActivityNotFoundException ignored) {
            return false;
        }
    }

    private void shareWhatsAppToCustomer(Uri uri, String caption, String phoneDigits) {
        if (phoneDigits == null || !phoneDigits.matches("^923\\d{9}$")) {
            Toast.makeText(this, "Please enter a valid Pakistan WhatsApp number.", Toast.LENGTH_LONG).show();
            return;
        }
        if (tryWhatsAppPackage(uri, caption, phoneDigits, "com.whatsapp")) return;
        if (tryWhatsAppPackage(uri, caption, phoneDigits, "com.whatsapp.w4b")) return;
        Toast.makeText(this, "WhatsApp was not found. Choose an app to share the report.", Toast.LENGTH_LONG).show();
        shareGeneral(uri, "image/png", "Share calculation image", caption);
    }

    private String whatsAppCaption(JSONObject o) {
        String customer = value(o, "customerName");
        String greeting = "-".equals(customer) ? "Assalam o Alaikum," : "Assalam o Alaikum " + customer + ",";
        return greeting + "\nPlease find attached your estimated property registry expense report prepared by Reliance Associates.\nContact: " + BUSINESS_PHONE;
    }

    private class ShareBridge {
        @JavascriptInterface
        public void shareWhatsAppImage(String reportJson) {
            runOnUiThread(() -> {
                Bitmap bitmap = null;
                try {
                    JSONObject o = new JSONObject(reportJson);
                    String phoneDigits = o.optString("customerPhoneDigits", "").replaceAll("\\D", "");
                    bitmap = buildReportBitmap(reportJson);
                    File file = writePng(bitmap);
                    Uri uri = uriForFile(file);
                    shareWhatsAppToCustomer(uri, whatsAppCaption(o), phoneDigits);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Could not create calculation image.", Toast.LENGTH_LONG).show();
                } finally {
                    if (bitmap != null) bitmap.recycle();
                }
            });
        }

        @JavascriptInterface
        public void sharePdf(String reportJson) {
            runOnUiThread(() -> {
                Bitmap bitmap = null;
                try {
                    bitmap = buildReportBitmap(reportJson);
                    File file = writePdf(bitmap);
                    Uri uri = uriForFile(file);
                    shareGeneral(uri, "application/pdf", "Share calculation PDF",
                            "Reliance Associates - Property Registry Expense Estimate | " + BUSINESS_PHONE);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Could not create calculation PDF.", Toast.LENGTH_LONG).show();
                } finally {
                    if (bitmap != null) bitmap.recycle();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
