Reliance Registry Calculator v1.2

Build-ready Android project for GitHub Actions / Android Studio.

Key v1.2 updates:
- PDF sharing removed.
- Branded WhatsApp image sharing retained and improved.
- Reliance logo watermark added to the calculator UI and share image.
- Property details fields added: Urban/Rural, District, Tehsil, City, Town/City, Qanoongoee, Mouza, Revenue Circle, Floor, Property Area, Land Classification, Location, Land Area, Khasra, Square No, Qila No.
- Official Punjab e-Stamp / PLRA DC Valuation link retained for rate verification.
- Land DC Value can auto-calculate from Land Area (Marla) x Official DC Rate per Marla, while remaining manually editable.
- Map Approval options: Approved, Not Approved, Not Applicable.
- PLRA fee logic: Rs 4,000 when Total DC Value is Rs 3,000,000 or below; 0.1% when above Rs 3,000,000.
- Buyer/Seller filer logic retained.
- WhatsApp report includes mandatory property fields plus DC valuation and registry expense breakdown.

Package: com.reliance.associates.registrycalculator
Minimum Android: API 23 (Android 6.0)
Version: 1.2 (versionCode 3)
