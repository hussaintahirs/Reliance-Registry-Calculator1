RELIANCE REGISTRY CALCULATOR - ANDROID PROJECT

App name: Reliance Registry Calculator
Package: com.reliance.associates.registrycalculator
Minimum Android: Android 6.0 (API 23)
Offline: Yes

CURRENT CALCULATION SETTINGS
Buyer:
- Stamp Duty: 1% of Total DC Value
- PLRA Registration: 0.1% only when Total DC Value > Rs 3,000,000
- TMA Tax: 1% of Total DC Value
- Registration Fee: Fixed Rs 2,000
- 236K Buyer Tax: 1.5% of Total DC Value
- Other Buyer Charges: editable

Seller:
- 236C Seller Tax: 4.5% of Total DC Value
- Map Penalty: 2% of Total DC Value only when map is not passed
- Other Seller Charges: editable

Building value:
Covered Area x Building/Construction DC Rate per sq ft
Total DC Value = Land DC Value + Building DC Value

HOW TO BUILD THE APK IN ANDROID STUDIO
1. Install Android Studio from https://developer.android.com/studio
2. Open Android Studio > Open and select this project folder.
3. Allow Gradle/SDK components to download and sync.
4. Click Build > Build App Bundle(s) / APK(s) > Build APK(s).
5. When complete, click Locate.
6. The debug APK is normally at:
   app/build/outputs/apk/debug/app-debug.apk

HOW TO INSTALL APK ON ANDROID PHONE
1. Copy app-debug.apk to the phone (Downloads folder is fine).
2. Open Settings > Security/Privacy > Install unknown apps.
3. Allow the app you use to open the APK (Files / My Files / Chrome).
4. Tap the APK file > Install.
5. If Play Protect warns that this is an app from outside Google Play, review the warning and continue only if you trust the file you built.
6. After installation, open Reliance Registry Calculator from the app drawer.

NOTE
This project does not use internet permissions and the calculator runs from local files.
