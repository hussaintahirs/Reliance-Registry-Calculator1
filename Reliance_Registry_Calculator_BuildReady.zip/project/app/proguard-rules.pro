# No custom ProGuard rules required for this offline WebView calculator.
