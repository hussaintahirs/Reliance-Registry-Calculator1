package com.reliance.associates.registrycalculator;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);

        webView.addJavascriptInterface(new ShareBridge(), "AndroidShare");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(MainActivity.this, "No browser available to open this link.", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                return false;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(MainActivity.this, "No browser available to open this link.", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                return false;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private Bitmap bitmapFromDataUrl(String dataUrl) {
        try {
            String base64 = dataUrl.substring(dataUrl.indexOf(',') + 1);
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        } catch (Exception e) {
            return null;
        }
    }

    private Uri uriForFile(File file) {
        return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
    }

    private void shareFile(Intent intent, File file, String chooserTitle) {
        Uri uri = uriForFile(file);
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(intent, chooserTitle));
    }

    private class ShareBridge {
        @JavascriptInterface
        public void shareWhatsAppImage(String dataUrl) {
            runOnUiThread(() -> {
                Bitmap bitmap = bitmapFromDataUrl(dataUrl);
                if (bitmap == null) {
                    Toast.makeText(MainActivity.this, "Could not create calculation image.", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    File file = new File(getCacheDir(), "Reliance_Registry_Estimate.png");
                    try (FileOutputStream out = new FileOutputStream(file)) {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                    }
                    Uri uri = uriForFile(file);
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("image/png");
                    share.putExtra(Intent.EXTRA_STREAM, uri);
                    share.putExtra(Intent.EXTRA_TEXT, "Reliance Associates - Registry Expense Estimate");
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    share.setPackage("com.whatsapp");
                    try {
                        startActivity(share);
                    } catch (ActivityNotFoundException e) {
                        share.setPackage("com.whatsapp.w4b");
                        try {
                            startActivity(share);
                        } catch (ActivityNotFoundException e2) {
                            share.setPackage(null);
                            startActivity(Intent.createChooser(share, "Share registry estimate"));
                        }
                    }
                } catch (IOException e) {
                    Toast.makeText(MainActivity.this, "Could not prepare image for sharing.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void sharePdf(String dataUrl) {
            runOnUiThread(() -> {
                Bitmap bitmap = bitmapFromDataUrl(dataUrl);
                if (bitmap == null) {
                    Toast.makeText(MainActivity.this, "Could not create PDF.", Toast.LENGTH_SHORT).show();
                    return;
                }
                File file = new File(getCacheDir(), "Reliance_Registry_Estimate.pdf");
                PdfDocument document = new PdfDocument();
                try {
                    final int pageWidth = 595;
                    final int pageHeight = 842;
                    final int margin = 28;
                    PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create();
                    PdfDocument.Page page = document.startPage(pageInfo);
                    Canvas canvas = page.getCanvas();
                    canvas.drawColor(Color.WHITE);
                    float scale = Math.min((pageWidth - (margin * 2f)) / bitmap.getWidth(), (pageHeight - (margin * 2f)) / bitmap.getHeight());
                    float drawWidth = bitmap.getWidth() * scale;
                    float drawHeight = bitmap.getHeight() * scale;
                    float left = (pageWidth - drawWidth) / 2f;
                    float top = (pageHeight - drawHeight) / 2f;
                    Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                    canvas.drawBitmap(bitmap, null, new RectF(left, top, left + drawWidth, top + drawHeight), paint);
                    document.finishPage(page);
                    try (FileOutputStream out = new FileOutputStream(file)) {
                        document.writeTo(out);
                    }
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("application/pdf");
                    share.putExtra(Intent.EXTRA_SUBJECT, "Reliance Registry Expense Estimate");
                    shareFile(share, file, "Share registry estimate PDF");
                } catch (IOException e) {
                    Toast.makeText(MainActivity.this, "Could not prepare PDF for sharing.", Toast.LENGTH_SHORT).show();
                } finally {
                    document.close();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
