package com.reliance.associates.registrycalculator;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends Activity {
    private WebView webView;

    private static final int REPORT_WIDTH = 1080;
    private static final int REPORT_HEIGHT = 2700;
    private static final int GREEN = Color.rgb(0, 107, 55);
    private static final int GREEN_BRIGHT = Color.rgb(7, 148, 71);
    private static final int LIGHT_GREEN = Color.rgb(234, 248, 239);
    private static final int SOFT = Color.rgb(247, 250, 248);
    private static final int INK = Color.rgb(21, 51, 41);
    private static final int MUTED = Color.rgb(95, 115, 106);
    private static final String BUSINESS_PHONE = "+92 300-9749221";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);

        webView.addJavascriptInterface(new ShareBridge(), "AndroidShare");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    openExternal(uri);
                    return true;
                }
                return false;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                    openExternal(Uri.parse(url));
                    return true;
                }
                return false;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No browser available to open this link.", Toast.LENGTH_SHORT).show();
        }
    }

    private Uri uriForFile(File file) {
        return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
    }

    private Paint paint(float size, int color, boolean bold) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        p.setTextSize(size);
        p.setColor(color);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL));
        return p;
    }

    private Paint centeredPaint(float size, int color, boolean bold) {
        Paint p = paint(size, color, bold);
        p.setTextAlign(Paint.Align.CENTER);
        return p;
    }

    private Bitmap loadLogo() {
        try (InputStream in = getAssets().open("reliance_report_logo.jpg")) {
            return BitmapFactory.decodeStream(in);
        } catch (IOException e) {
            return null;
        }
    }

    private String value(JSONObject obj, String key) {
        String v = obj.optString(key, "-");
        return v == null || v.trim().isEmpty() ? "-" : v.trim();
    }

    private boolean containsUrdu(String text) {
        if (text == null) return false;
        for (int i = 0; i < text.length(); ) {
            int cp = text.codePointAt(i);
            i += Character.charCount(cp);
            if ((cp >= 0x0600 && cp <= 0x06FF) ||
                    (cp >= 0x0750 && cp <= 0x077F) ||
                    (cp >= 0x08A0 && cp <= 0x08FF)) {
                return true;
            }
        }
        return false;
    }

    private Typeface bundledUrduTypeface;

    private Typeface urduTypeface() {
        if (bundledUrduTypeface == null) {
            try {
                bundledUrduTypeface = Typeface.createFromAsset(getAssets(), "fonts/JameelNooriKasheeda.ttf");
            } catch (Throwable ignored) {
                bundledUrduTypeface = Typeface.create("serif", Typeface.NORMAL);
            }
        }
        return bundledUrduTypeface;
    }

    private Paint fitRightAlignedPaint(String text, float startSize, float minSize, float maxWidth,
                                       int color, boolean bold, boolean urdu) {
        Paint p = paint(startSize, color, bold);
        if (urdu) p.setTypeface(urduTypeface());
        p.setTextAlign(Paint.Align.RIGHT);
        while (p.getTextSize() > minSize && p.measureText(text) > maxWidth) {
            p.setTextSize(p.getTextSize() - 1f);
        }
        return p;
    }

    private float drawSectionTitle(Canvas canvas, String title, float y) {
        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setColor(LIGHT_GREEN);
        canvas.drawRoundRect(new RectF(60, y, 1020, y + 54), 18, 18, bg);
        canvas.drawText(title, 84, y + 37, paint(28, GREEN, true));
        return y + 78;
    }

    private float drawRow(Canvas canvas, String label, String val, float y, boolean emphasis) {
        if (emphasis) {
            Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
            bg.setColor(LIGHT_GREEN);
            canvas.drawRoundRect(new RectF(70, y - 31, 1010, y + 18), 13, 13, bg);
        }
        Paint lp = paint(emphasis ? 25 : 23, INK, emphasis);
        boolean urdu = containsUrdu(val);
        Paint vp = fitRightAlignedPaint(val, urdu ? 34 : (emphasis ? 26 : 23), urdu ? 22 : 18,
                540, emphasis ? GREEN : INK, emphasis && !urdu, urdu);
        canvas.drawText(label, 82, y, lp);
        canvas.drawText(val, 998, y, vp);
        return y + (emphasis ? 55 : (urdu ? 50 : 41));
    }

    private float drawCustomerRow(Canvas canvas, String label, String val, float y, boolean nameRow) {
        canvas.drawText(label, 82, y, paint(22, MUTED, true));
        boolean urdu = nameRow && containsUrdu(val);
        Paint vp = fitRightAlignedPaint(val, urdu ? 40 : 27, urdu ? 25 : 21,
                650, INK, nameRow && !urdu, urdu);
        canvas.drawText(val, 998, y, vp);
        return y + (urdu ? 63 : 44);
    }

    private float drawWrappedCentered(Canvas canvas, String text, float centerX, float y,
                                      float maxWidth, Paint p, float lineHeight) {
        String[] words = text.split("\\s+");
        StringBuilder line = new StringBuilder();
        p.setTextAlign(Paint.Align.CENTER);
        for (String word : words) {
            String test = line.length() == 0 ? word : line + " " + word;
            if (p.measureText(test) > maxWidth && line.length() > 0) {
                canvas.drawText(line.toString(), centerX, y, p);
                y += lineHeight;
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(test);
            }
        }
        if (line.length() > 0) {
            canvas.drawText(line.toString(), centerX, y, p);
            y += lineHeight;
        }
        return y;
    }

    private void drawCenteredLogo(Canvas canvas, Bitmap logo) {
        if (logo == null) return;
        Paint white = new Paint(Paint.ANTI_ALIAS_FLAG);
        white.setColor(Color.WHITE);
        canvas.drawRoundRect(new RectF(425, 18, 655, 222), 28, 28, white);
        float maxW = 205f;
        float maxH = 180f;
        float scale = Math.min(maxW / logo.getWidth(), maxH / logo.getHeight());
        float w = logo.getWidth() * scale;
        float h = logo.getHeight() * scale;
        canvas.drawBitmap(logo, null,
                new RectF(540 - w / 2f, 120 - h / 2f, 540 + w / 2f, 120 + h / 2f),
                new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
    }

    private Bitmap buildReportBitmap(String reportJson) throws Exception {
        JSONObject o = new JSONObject(reportJson);
        Bitmap bitmap = Bitmap.createBitmap(REPORT_WIDTH, REPORT_HEIGHT, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(Color.WHITE);

        Bitmap logo = loadLogo();
        if (logo != null) {
            Paint wm = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            wm.setAlpha(9);
            float wmW = 620f;
            float wmH = wmW * logo.getHeight() / (float) logo.getWidth();
            canvas.drawBitmap(logo, null,
                    new RectF((REPORT_WIDTH - wmW) / 2f, 900, (REPORT_WIDTH + wmW) / 2f, 900 + wmH), wm);
        }

        Paint header = new Paint(Paint.ANTI_ALIAS_FLAG);
        header.setShader(new LinearGradient(0, 0, REPORT_WIDTH, 430, GREEN, GREEN_BRIGHT, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, REPORT_WIDTH, 430, header);
        drawCenteredLogo(canvas, logo);
        canvas.drawText("RELIANCE ASSOCIATES", 540, 270, centeredPaint(45, Color.WHITE, true));
        canvas.drawText("Property Registry Expense Estimate", 540, 314, centeredPaint(30, Color.WHITE, true));
        canvas.drawText("Financial Year 2026 - 2027", 540, 349, centeredPaint(21, Color.WHITE, false));
        canvas.drawText("Contact: " + BUSINESS_PHONE, 540, 378, centeredPaint(20, Color.WHITE, true));
        canvas.drawText("Report Date: " + value(o, "reportDate"), 540, 406, centeredPaint(19, Color.WHITE, false));

        float y = 466;

        y = drawSectionTitle(canvas, "Customer Details", y);
        Paint customerBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        customerBg.setColor(SOFT);
        canvas.drawRoundRect(new RectF(60, y - 16, 1020, y + 105), 18, 18, customerBg);
        y += 19;
        y = drawCustomerRow(canvas, "Customer Name", value(o, "customerName"), y, true);
        y = drawCustomerRow(canvas, "Customer Phone", value(o, "customerPhone"), y, false) + 12;

        y = drawSectionTitle(canvas, "Property Details", y);
        y = drawRow(canvas, "Property Type", value(o, "propertyType"), y, false);
        y = drawRow(canvas, "District", value(o, "district"), y, false);
        y = drawRow(canvas, "Tehsil", value(o, "tehsil"), y, false);
        y = drawRow(canvas, "Location / Mouza", value(o, "locationMouza"), y, false);
        y = drawRow(canvas, "Land Area", value(o, "landArea"), y, false) + 10;

        y = drawSectionTitle(canvas, "Property Valuation", y);
        y = drawRow(canvas, "Land DC Rate", value(o, "landDcRate"), y, false);
        y = drawRow(canvas, "Land Value", value(o, "landValue"), y, false);
        y = drawRow(canvas, "Covered Area", value(o, "coveredArea"), y, false);
        y = drawRow(canvas, "Building DC Rate", value(o, "buildingRate"), y, false);
        y = drawRow(canvas, "Building Value", value(o, "buildingValue"), y, false);
        y = drawRow(canvas, "Total DC Value", value(o, "totalDc"), y, true) + 10;

        y = drawSectionTitle(canvas, "Buyer Expenses", y);
        y = drawRow(canvas, "Buyer Filer", value(o, "buyerFiler"), y, false);
        y = drawRow(canvas, "Stamp Duty (1%)", value(o, "stamp"), y, false);
        y = drawRow(canvas, "PLRA Registration", value(o, "plra"), y, false);
        y = drawRow(canvas, "TMA Tax (1%)", value(o, "tma"), y, false);
        y = drawRow(canvas, "Registration Fee", value(o, "registration"), y, false);
        y = drawRow(canvas, "236K Buyer Tax " + value(o, "buyerRate"), value(o, "buyerTax"), y, false);
        y = drawRow(canvas, "Other Buyer Charges", value(o, "otherBuyer"), y, false);
        y = drawRow(canvas, "TOTAL BUYER EXPENSE", value(o, "buyerTotal"), y, true) + 10;

        y = drawSectionTitle(canvas, "Seller Expenses", y);
        y = drawRow(canvas, "Seller Filer", value(o, "sellerFiler"), y, false);
        y = drawRow(canvas, "236C Seller Tax " + value(o, "sellerRate"), value(o, "sellerTax"), y, false);
        y = drawRow(canvas, "Map Approval Status", value(o, "mapApproval"), y, false);
        y = drawRow(canvas, "Map Approval Penalty", value(o, "mapPenalty"), y, false);
        y = drawRow(canvas, "Other Seller Charges", value(o, "otherSeller"), y, false);
        y = drawRow(canvas, "TOTAL SELLER EXPENSE", value(o, "sellerTotal"), y, true) + 18;

        Paint totalBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        totalBg.setColor(GREEN);
        canvas.drawRoundRect(new RectF(60, y, 1020, y + 184), 22, 22, totalBg);
        canvas.drawText("Buyer Total", 100, y + 38, paint(20, Color.WHITE, false));
        canvas.drawText(value(o, "buyerTotal"), 100, y + 73, paint(27, Color.WHITE, true));
        Paint sellerLabel = paint(20, Color.WHITE, false);
        sellerLabel.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText("Seller Total", 980, y + 38, sellerLabel);
        Paint sellerValue = paint(27, Color.WHITE, true);
        sellerValue.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText(value(o, "sellerTotal"), 980, y + 73, sellerValue);
        canvas.drawText(value(o, "grandTotal"), 540, y + 129, centeredPaint(42, Color.WHITE, true));
        canvas.drawText("TOTAL ESTIMATED REGISTRY EXPENSES", 540, y + 162, centeredPaint(21, Color.WHITE, true));
        y += 226;

        canvas.drawText("Reliance Associates", 540, y, centeredPaint(26, GREEN, true));
        canvas.drawText("Contact: " + BUSINESS_PHONE, 540, y + 34, centeredPaint(23, GREEN, true));
        canvas.drawText("Your Trusted Property & Documentation Partner", 540, y + 69,
                centeredPaint(20, INK, false));
        y += 114;

        String disclaimer = "Disclaimer: This calculation is for informational purposes only for the Financial Year 2026 - 2027. Reliance Associates assumes no responsibility for any discrepancies or changes in government tax rates.";
        drawWrappedCentered(canvas, disclaimer, 540, y, 930, paint(18, MUTED, false), 27);

        return bitmap;
    }

    private File writePng(Bitmap bitmap) throws IOException {
        File file = new File(getCacheDir(), "Reliance_Registry_Calculation.png");
        try (FileOutputStream out = new FileOutputStream(file)) {
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                throw new IOException("PNG compression failed");
            }
        }
        return file;
    }

    private File writePdf(Bitmap bitmap) throws IOException {
        File file = new File(getCacheDir(), "Reliance_Registry_Calculation.pdf");
        PdfDocument document = new PdfDocument();
        try {
            int pageWidth = 595;
            int pageHeight = 842;
            int margin = 20;
            float contentW = pageWidth - margin * 2f;
            float contentH = pageHeight - margin * 2f;
            float scale = contentW / bitmap.getWidth();
            int sourceSliceHeight = Math.max(1, (int) Math.floor(contentH / scale));
            int top = 0;
            int pageNumber = 1;
            Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

            while (top < bitmap.getHeight()) {
                int bottom = Math.min(bitmap.getHeight(), top + sourceSliceHeight);
                int sliceHeight = bottom - top;
                float drawHeight = sliceHeight * scale;
                PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create();
                PdfDocument.Page page = document.startPage(pageInfo);
                Canvas canvas = page.getCanvas();
                canvas.drawColor(Color.WHITE);
                Rect src = new Rect(0, top, bitmap.getWidth(), bottom);
                RectF dst = new RectF(margin, margin, pageWidth - margin, margin + drawHeight);
                canvas.drawBitmap(bitmap, src, dst, imagePaint);
                document.finishPage(page);
                top = bottom;
                pageNumber++;
            }

            try (FileOutputStream out = new FileOutputStream(file)) {
                document.writeTo(out);
            }
        } finally {
            document.close();
        }
        return file;
    }

    private void shareGeneral(Uri uri, String mimeType, String title, String text) {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType(mimeType);
        share.putExtra(Intent.EXTRA_STREAM, uri);
        if (text != null) share.putExtra(Intent.EXTRA_TEXT, text);
        share.setClipData(ClipData.newRawUri("Reliance Registry Calculation", uri));
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(share, title));
    }

    private boolean tryWhatsAppPackage(Uri uri, String caption, String phoneDigits, String packageName) {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("image/png");
        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.putExtra(Intent.EXTRA_TEXT, caption);
        share.putExtra("jid", phoneDigits + "@s.whatsapp.net");
        share.setClipData(ClipData.newRawUri("Reliance Registry Calculation", uri));
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        share.setPackage(packageName);
        try {
            startActivity(share);
            return true;
        } catch (ActivityNotFoundException ignored) {
            return false;
        }
    }

    private void shareWhatsAppToCustomer(Uri uri, String caption, String phoneDigits) {
        if (phoneDigits == null || !phoneDigits.matches("^923\\d{9}$")) {
            Toast.makeText(this, "Please enter a valid Pakistan WhatsApp number.", Toast.LENGTH_LONG).show();
            return;
        }
        if (tryWhatsAppPackage(uri, caption, phoneDigits, "com.whatsapp")) return;
        if (tryWhatsAppPackage(uri, caption, phoneDigits, "com.whatsapp.w4b")) return;
        Toast.makeText(this, "WhatsApp was not found. Choose an app to share the report.", Toast.LENGTH_LONG).show();
        shareGeneral(uri, "image/png", "Share calculation image", caption);
    }

    private String whatsAppCaption(JSONObject o) {
        String customer = value(o, "customerName");
        String greeting = "-".equals(customer) ? "Assalam o Alaikum," : "Assalam o Alaikum " + customer + ",";
        return greeting + "\nPlease find attached your estimated property registry expense report prepared by Reliance Associates.\nContact: " + BUSINESS_PHONE;
    }

    private class ShareBridge {
        @JavascriptInterface
        public void shareWhatsAppImage(String reportJson) {
            runOnUiThread(() -> {
                Bitmap bitmap = null;
                try {
                    JSONObject o = new JSONObject(reportJson);
                    String phoneDigits = o.optString("customerPhoneDigits", "").replaceAll("\\D", "");
                    bitmap = buildReportBitmap(reportJson);
                    File file = writePng(bitmap);
                    Uri uri = uriForFile(file);
                    shareWhatsAppToCustomer(uri, whatsAppCaption(o), phoneDigits);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Could not create calculation image.", Toast.LENGTH_LONG).show();
                } finally {
                    if (bitmap != null) bitmap.recycle();
                }
            });
        }

        @JavascriptInterface
        public void sharePdf(String reportJson) {
            runOnUiThread(() -> {
                Bitmap bitmap = null;
                try {
                    bitmap = buildReportBitmap(reportJson);
                    File file = writePdf(bitmap);
                    Uri uri = uriForFile(file);
                    shareGeneral(uri, "application/pdf", "Share calculation PDF",
                            "Reliance Associates - Property Registry Expense Estimate | " + BUSINESS_PHONE);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Could not create calculation PDF.", Toast.LENGTH_LONG).show();
                } finally {
                    if (bitmap != null) bitmap.recycle();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("window.handleNativeBack ? window.handleNativeBack() : false", result -> {
                if (!"true".equals(result)) {
                    MainActivity.super.onBackPressed();
                }
            });
        } else {
            super.onBackPressed();
        }
    }
}
