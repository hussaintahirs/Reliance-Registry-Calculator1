package com.reliance.associates.registrycalculator;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private static final String OFFICIAL_DC_URL = "https://es.punjab-zameen.gov.pk/eStampCitizenPortal/ChallanFormView/RateOfChallanView?name=PropertyDCValuation&vCount=286459";
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);

        webView.addJavascriptInterface(new AppBridge(), "AndroidApp");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(MainActivity.this, "No browser available to open this link.", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                return false;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(MainActivity.this, "No browser available to open this link.", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                return false;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private Bitmap bitmapFromDataUrl(String dataUrl) {
        try {
            String base64 = dataUrl.substring(dataUrl.indexOf(',') + 1);
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        } catch (Exception e) {
            return null;
        }
    }

    private Uri uriForFile(File file) {
        return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void openOfficialValuationDialog() {
        final Dialog dialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar_Fullscreen);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(16), dp(12), dp(16), dp(10));
        header.setBackgroundColor(Color.rgb(0, 107, 55));

        TextView title = new TextView(this);
        title.setText("Official Punjab DC Valuation");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setGravity(Gravity.START);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView help = new TextView(this);
        help.setText("Complete the official form, tap Find Land Rate, then tap USE THIS VALUATION below.");
        help.setTextColor(Color.rgb(225, 245, 234));
        help.setTextSize(12);
        help.setPadding(0, dp(4), 0, 0);
        header.addView(help, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(header);

        final WebView portal = new WebView(this);
        WebSettings ps = portal.getSettings();
        ps.setJavaScriptEnabled(true);
        ps.setDomStorageEnabled(true);
        ps.setAllowFileAccess(false);
        ps.setAllowContentAccess(false);
        ps.setSupportZoom(true);
        ps.setBuiltInZoomControls(true);
        ps.setDisplayZoomControls(false);
        ps.setUseWideViewPort(true);
        ps.setLoadWithOverviewMode(true);
        ps.setTextZoom(100);

        portal.addJavascriptInterface(new PortalBridge(dialog), "ReliancePortal");
        portal.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String host = request.getUrl().getHost();
                if (host != null && (host.endsWith("punjab-zameen.gov.pk") || host.endsWith("punjab.gov.pk"))) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, request.getUrl()));
                } catch (Exception ignored) {}
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                try {
                    Uri uri = Uri.parse(url);
                    String host = uri.getHost();
                    if (host != null && (host.endsWith("punjab-zameen.gov.pk") || host.endsWith("punjab.gov.pk"))) {
                        return false;
                    }
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                } catch (Exception e) {
                    return false;
                }
            }
        });
        portal.loadUrl(OFFICIAL_DC_URL);
        root.addView(portal, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setPadding(dp(10), dp(8), dp(10), dp(10));
        buttons.setGravity(Gravity.CENTER_VERTICAL);

        Button close = new Button(this);
        close.setText("CLOSE");
        close.setOnClickListener(v -> dialog.dismiss());
        buttons.addView(close, new LinearLayout.LayoutParams(0, dp(52), 0.34f));

        Button use = new Button(this);
        use.setText("USE THIS VALUATION");
        use.setTextColor(Color.WHITE);
        use.setBackgroundColor(Color.rgb(7, 148, 71));
        LinearLayout.LayoutParams useParams = new LinearLayout.LayoutParams(0, dp(52), 0.66f);
        useParams.setMargins(dp(8), 0, 0, 0);
        buttons.addView(use, useParams);

        use.setOnClickListener(v -> {
            String js = "(function(){" +
                    "function clean(s){return (s||'').replace(/\\s+/g,' ').trim();}" +
                    "function ctx(el){var t='';try{var p=el.closest('.form-group,.row,.control-group,.field,.input-group,td,li,div');if(p)t=clean(p.innerText).slice(0,220);}catch(e){}return t;}" +
                    "var data={url:location.href,title:document.title||'',bodyText:(document.body&&document.body.innerText)||'',selects:[],inputs:[],radios:[]};" +
                    "Array.prototype.forEach.call(document.querySelectorAll('select'),function(s){var o=s.options&&s.selectedIndex>=0?s.options[s.selectedIndex]:null;data.selects.push({id:s.id||'',name:s.name||'',value:s.value||'',text:o?clean(o.text):'',context:ctx(s)});});" +
                    "Array.prototype.forEach.call(document.querySelectorAll('input'),function(i){var type=(i.type||'').toLowerCase();if(type==='hidden'||type==='button'||type==='submit'||type==='reset')return;data.inputs.push({id:i.id||'',name:i.name||'',type:type,value:i.value||'',placeholder:i.placeholder||'',checked:!!i.checked,context:ctx(i)});});" +
                    "Array.prototype.forEach.call(document.querySelectorAll('input[type=radio]'),function(r){if(r.checked){data.radios.push({id:r.id||'',name:r.name||'',value:r.value||'',context:ctx(r)});}});" +
                    "ReliancePortal.submitSnapshot(JSON.stringify(data));" +
                    "})();";
            portal.evaluateJavascript(js, null);
        });

        root.addView(buttons);
        dialog.setContentView(root);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.WHITE));
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
        dialog.show();
    }

    private class PortalBridge {
        private final Dialog dialog;
        PortalBridge(Dialog dialog) { this.dialog = dialog; }

        @JavascriptInterface
        public void submitSnapshot(String json) {
            runOnUiThread(() -> {
                try {
                    JSONObject obj = new JSONObject(json);
                    String body = obj.optString("bodyText", "");
                    if (body.length() < 20) {
                        Toast.makeText(MainActivity.this, "Official page data could not be read. Please try again.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    String quoted = JSONObject.quote(json);
                    webView.evaluateJavascript("window.importOfficialValuation && window.importOfficialValuation(" + quoted + ");", null);
                    if (dialog != null && dialog.isShowing()) dialog.dismiss();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Could not import official valuation. Please try again.", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    private class AppBridge {
        @JavascriptInterface
        public void openOfficialValuation() {
            runOnUiThread(MainActivity.this::openOfficialValuationDialog);
        }

        @JavascriptInterface
        public void openExternal(String url) {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Unable to open link.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void shareWhatsAppImage(String dataUrl) {
            runOnUiThread(() -> {
                Bitmap bitmap = bitmapFromDataUrl(dataUrl);
                if (bitmap == null) {
                    Toast.makeText(MainActivity.this, "Could not create calculation image.", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    File file = new File(getCacheDir(), "Reliance_Registry_Estimate.png");
                    try (FileOutputStream out = new FileOutputStream(file)) {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                    }
                    Uri uri = uriForFile(file);
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("image/png");
                    share.putExtra(Intent.EXTRA_STREAM, uri);
                    share.putExtra(Intent.EXTRA_TEXT, "Reliance Associates - Registry Expense Estimate");
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    share.setPackage("com.whatsapp");
                    try {
                        startActivity(share);
                    } catch (ActivityNotFoundException e) {
                        share.setPackage("com.whatsapp.w4b");
                        try {
                            startActivity(share);
                        } catch (ActivityNotFoundException e2) {
                            share.setPackage(null);
                            startActivity(Intent.createChooser(share, "Share registry estimate"));
                        }
                    }
                } catch (IOException e) {
                    Toast.makeText(MainActivity.this, "Could not prepare image for sharing.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
