package com.reliance.associates.registrycalculator;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends Activity {
    private WebView webView;

    private static final int REPORT_WIDTH = 1080;
    private static final int REPORT_HEIGHT = 1880;
    private static final int GREEN = Color.rgb(0, 107, 55);
    private static final int LIGHT_GREEN = Color.rgb(234, 248, 239);
    private static final int INK = Color.rgb(21, 51, 41);
    private static final int MUTED = Color.rgb(95, 115, 106);
    private static final int LINE = Color.rgb(217, 232, 223);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);

        webView.addJavascriptInterface(new ShareBridge(), "AndroidShare");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(MainActivity.this, "No browser available to open this link.", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                return false;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(MainActivity.this, "No browser available to open this link.", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                return false;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private Uri uriForFile(File file) {
        return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
    }

    private Paint paint(float size, int color, boolean bold) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        p.setTextSize(size);
        p.setColor(color);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL));
        return p;
    }

    private Bitmap loadLogo() {
        try (InputStream in = getAssets().open("reliance_logo.png")) {
            return BitmapFactory.decodeStream(in);
        } catch (IOException e) {
            return null;
        }
    }

    private String value(JSONObject obj, String key) {
        String v = obj.optString(key, "-");
        return v == null || v.trim().isEmpty() ? "-" : v;
    }

    private float drawSection(Canvas canvas, String title, float y) {
        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setColor(LIGHT_GREEN);
        canvas.drawRoundRect(new RectF(60, y, 1020, y + 58), 12, 12, bg);
        canvas.drawText(title, 80, y + 39, paint(30, GREEN, true));
        return y + 82;
    }

    private float drawRow(Canvas canvas, String label, String val, float y, boolean bold) {
        Paint lp = paint(25, INK, bold);
        Paint vp = paint(25, bold ? GREEN : INK, bold);
        canvas.drawText(label, 70, y, lp);
        vp.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText(val, 1010, y, vp);
        Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        line.setColor(LINE);
        line.setStrokeWidth(1.5f);
        canvas.drawLine(70, y + 16, 1010, y + 16, line);
        return y + 47;
    }

    private float drawWrappedText(Canvas canvas, String text, float x, float y, float maxWidth, Paint p, float lineHeight) {
        String[] words = text.split("\\s+");
        StringBuilder line = new StringBuilder();
        for (String word : words) {
            String test = line.length() == 0 ? word : line + " " + word;
            if (p.measureText(test) > maxWidth && line.length() > 0) {
                canvas.drawText(line.toString(), x, y, p);
                y += lineHeight;
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(test);
            }
        }
        if (line.length() > 0) {
            canvas.drawText(line.toString(), x, y, p);
            y += lineHeight;
        }
        return y;
    }

    private Bitmap buildReportBitmap(String reportJson) throws Exception {
        JSONObject o = new JSONObject(reportJson);
        Bitmap bitmap = Bitmap.createBitmap(REPORT_WIDTH, REPORT_HEIGHT, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(Color.WHITE);

        Bitmap logo = loadLogo();
        if (logo != null) {
            Paint wm = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            wm.setAlpha(14);
            float wmW = 560f;
            float wmH = wmW * logo.getHeight() / (float) logo.getWidth();
            canvas.drawBitmap(logo, null, new RectF((REPORT_WIDTH - wmW) / 2f, 720, (REPORT_WIDTH + wmW) / 2f, 720 + wmH), wm);
        }

        Paint header = new Paint(Paint.ANTI_ALIAS_FLAG);
        header.setColor(GREEN);
        canvas.drawRect(0, 0, REPORT_WIDTH, 220, header);
        canvas.drawText("Reliance Associates", 60, 88, paint(53, Color.WHITE, true));
        canvas.drawText("Registry Expense Calculation", 60, 148, paint(37, Color.WHITE, true));
        canvas.drawText("Financial Year 2026 - 2027", 60, 190, paint(24, Color.WHITE, false));

        if (logo != null) {
            Paint white = new Paint(Paint.ANTI_ALIAS_FLAG);
            white.setColor(Color.WHITE);
            canvas.drawRoundRect(new RectF(835, 34, 1015, 186), 14, 14, white);
            float maxW = 150, maxH = 120;
            float scale = Math.min(maxW / logo.getWidth(), maxH / logo.getHeight());
            float w = logo.getWidth() * scale;
            float h = logo.getHeight() * scale;
            canvas.drawBitmap(logo, null, new RectF(925 - w / 2f, 110 - h / 2f, 925 + w / 2f, 110 + h / 2f), new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
        }

        float y = 270;
        y = drawSection(canvas, "Property / DC Valuation", y);
        y = drawRow(canvas, "Land DC Value", value(o, "landDc"), y, false);
        y = drawRow(canvas, "Covered Area", value(o, "coveredArea"), y, false);
        y = drawRow(canvas, "Building DC Rate / sq ft", value(o, "buildingRate"), y, false);
        y = drawRow(canvas, "Building DC Value", value(o, "buildingValue"), y, false);
        y = drawRow(canvas, "Total DC Value", value(o, "totalDc"), y, true);
        y = drawRow(canvas, "Map Approval", value(o, "mapApproval"), y, false) + 12;

        y = drawSection(canvas, "Buyer Expenses", y);
        y = drawRow(canvas, "Buyer Filer?", value(o, "buyerFiler"), y, false);
        y = drawRow(canvas, "Stamp Duty (1%)", value(o, "stamp"), y, false);
        y = drawRow(canvas, "PLRA Registration", value(o, "plra"), y, false);
        y = drawRow(canvas, "TMA Tax (1%)", value(o, "tma"), y, false);
        y = drawRow(canvas, "Registration Fee", value(o, "registration"), y, false);
        y = drawRow(canvas, "236K Buyer Tax " + value(o, "buyerRate"), value(o, "buyerTax"), y, false);
        y = drawRow(canvas, "Other Buyer Charges", value(o, "otherBuyer"), y, false);
        y = drawRow(canvas, "TOTAL BUYER EXPENSE", value(o, "buyerTotal"), y, true) + 12;

        y = drawSection(canvas, "Seller Expenses", y);
        y = drawRow(canvas, "Seller Filer?", value(o, "sellerFiler"), y, false);
        y = drawRow(canvas, "236C Seller Tax " + value(o, "sellerRate"), value(o, "sellerTax"), y, false);
        y = drawRow(canvas, "Map Penalty", value(o, "mapPenalty"), y, false);
        y = drawRow(canvas, "Other Seller Charges", value(o, "otherSeller"), y, false);
        y = drawRow(canvas, "TOTAL SELLER EXPENSE", value(o, "sellerTotal"), y, true) + 20;

        Paint totalBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        totalBg.setColor(GREEN);
        canvas.drawRoundRect(new RectF(60, y, 1020, y + 110), 16, 16, totalBg);
        canvas.drawText("TOTAL REGISTRY EXPENSES", 82, y + 47, paint(29, Color.WHITE, true));
        Paint totalValue = paint(39, Color.WHITE, true);
        totalValue.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText(value(o, "grandTotal"), 998, y + 67, totalValue);
        y += 145;

        String disclaimer = "Disclaimer: This calculation is for informational purposes only for the Financial Year 2026 - 2027. Reliance Associates assumes no responsibility for any discrepancies or changes in government tax rates.";
        y = drawWrappedText(canvas, disclaimer, 70, y, 940, paint(21, MUTED, false), 30);
        canvas.drawText("Reliance Associates - All Services Under One Roof", 70, y + 35, paint(23, GREEN, true));

        return bitmap;
    }

    private File writePng(Bitmap bitmap) throws IOException {
        File file = new File(getCacheDir(), "Reliance_Registry_Calculation.png");
        try (FileOutputStream out = new FileOutputStream(file)) {
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                throw new IOException("PNG compression failed");
            }
        }
        return file;
    }

    private File writePdf(Bitmap bitmap) throws IOException {
        File file = new File(getCacheDir(), "Reliance_Registry_Calculation.pdf");
        PdfDocument document = new PdfDocument();
        try {
            int pageWidth = 595;
            int pageHeight = 842;
            int margin = 24;
            PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create();
            PdfDocument.Page page = document.startPage(pageInfo);
            Canvas canvas = page.getCanvas();
            canvas.drawColor(Color.WHITE);
            float scale = Math.min((pageWidth - margin * 2f) / bitmap.getWidth(), (pageHeight - margin * 2f) / bitmap.getHeight());
            float w = bitmap.getWidth() * scale;
            float h = bitmap.getHeight() * scale;
            float left = (pageWidth - w) / 2f;
            float top = (pageHeight - h) / 2f;
            canvas.drawBitmap(bitmap, null, new RectF(left, top, left + w, top + h), new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
            document.finishPage(page);
            try (FileOutputStream out = new FileOutputStream(file)) {
                document.writeTo(out);
            }
        } finally {
            document.close();
        }
        return file;
    }

    private void shareUri(Uri uri, String mimeType, String title, String text, String preferredPackage) {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType(mimeType);
        share.putExtra(Intent.EXTRA_STREAM, uri);
        if (text != null) share.putExtra(Intent.EXTRA_TEXT, text);
        share.setClipData(ClipData.newRawUri("Reliance Registry Calculation", uri));
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        if (preferredPackage != null) {
            share.setPackage(preferredPackage);
            try {
                startActivity(share);
                return;
            } catch (ActivityNotFoundException ignored) {
                share.setPackage("com.whatsapp.w4b");
                try {
                    startActivity(share);
                    return;
                } catch (ActivityNotFoundException ignored2) {
                    share.setPackage(null);
                }
            }
        }
        startActivity(Intent.createChooser(share, title));
    }

    private class ShareBridge {
        @JavascriptInterface
        public void shareWhatsAppImage(String reportJson) {
            runOnUiThread(() -> {
                Bitmap bitmap = null;
                try {
                    bitmap = buildReportBitmap(reportJson);
                    File file = writePng(bitmap);
                    Uri uri = uriForFile(file);
                    shareUri(uri, "image/png", "Share calculation image", "Reliance Associates - Registry Expense Calculation", "com.whatsapp");
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Could not create calculation image.", Toast.LENGTH_LONG).show();
                } finally {
                    if (bitmap != null) bitmap.recycle();
                }
            });
        }

        @JavascriptInterface
        public void sharePdf(String reportJson) {
            runOnUiThread(() -> {
                Bitmap bitmap = null;
                try {
                    bitmap = buildReportBitmap(reportJson);
                    File file = writePdf(bitmap);
                    Uri uri = uriForFile(file);
                    shareUri(uri, "application/pdf", "Share calculation PDF", "Reliance Associates - Registry Expense Calculation", null);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Could not create calculation PDF.", Toast.LENGTH_LONG).show();
                } finally {
                    if (bitmap != null) bitmap.recycle();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
