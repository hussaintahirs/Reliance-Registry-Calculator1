package com.reliance.associates.registrycalculator;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private static final String OFFICIAL_DC_URL = "https://es.punjab-zameen.gov.pk/eStampCitizenPortal/ChallanFormView/RateOfChallanView?name=PropertyDCValuation&vCount=286459";
    private WebView webView;
    private WebView officialWebView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean officialReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        officialWebView = new WebView(this);

        root.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        FrameLayout.LayoutParams hiddenParams = new FrameLayout.LayoutParams(1, 1);
        officialWebView.setAlpha(0.01f);
        root.addView(officialWebView, hiddenParams);
        setContentView(root);

        configureMainWebView();
        configureOfficialSyncWebView();

        webView.loadUrl("file:///android_asset/index.html");
        officialWebView.loadUrl(OFFICIAL_DC_URL);
    }

    private void configureMainWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);

        webView.addJavascriptInterface(new AppBridge(), "AndroidApp");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(MainActivity.this, "No browser available to open this link.", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                return false;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(MainActivity.this, "No browser available to open this link.", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                return false;
            }
        });
    }

    private void configureOfficialSyncWebView() {
        WebSettings ps = officialWebView.getSettings();
        ps.setJavaScriptEnabled(true);
        ps.setDomStorageEnabled(true);
        ps.setAllowFileAccess(false);
        ps.setAllowContentAccess(false);
        ps.setSupportZoom(false);
        ps.setTextZoom(100);

        officialWebView.addJavascriptInterface(new OfficialSyncBridge(), "RelianceSync");
        officialWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String host = request.getUrl().getHost();
                return host == null || !(host.endsWith("punjab-zameen.gov.pk") || host.endsWith("punjab.gov.pk"));
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                try {
                    String host = Uri.parse(url).getHost();
                    return host == null || !(host.endsWith("punjab-zameen.gov.pk") || host.endsWith("punjab.gov.pk"));
                } catch (Exception e) {
                    return true;
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                officialReady = true;
                captureOfficialOptions(500);
                captureOfficialOptions(1500);
                captureOfficialOptions(3000);
            }
        });
    }

    private String portalHelpers() {
        return "function clean(s){return (s||'').replace(/\\s+/g,' ').trim();}" +
                "function norm(s){return clean(s).toLowerCase().replace(/[^a-z0-9]+/g,' ');}" +
                "function visible(el){try{var r=el.getBoundingClientRect();var st=getComputedStyle(el);return st.display!=='none'&&st.visibility!=='hidden'&&r.width>=0&&r.height>=0;}catch(e){return true;}}" +
                "function desc(el){var a=[];a.push(el.id||'',el.name||'',el.getAttribute('aria-label')||'',el.title||'',el.placeholder||'');" +
                "try{if(el.id){var l=document.querySelector('label[for=\\\"'+el.id.replace(/\\\"/g,'')+'\\\"]');if(l)a.push(l.innerText||l.textContent||'');}}catch(e){}" +
                "try{var prev=el.previousElementSibling;if(prev){var tx=clean(prev.innerText||prev.textContent||'');if(tx.length<90)a.push(tx);}var p=el.parentElement;if(p){var pt=clean(p.innerText||'');if(pt.length<140)a.push(pt);}}catch(e){}return clean(a.join(' '));}" +
                "function kind(el,idx){var m=norm(desc(el));if(m.indexOf('district')>=0)return'district';if(m.indexOf('tehsil')>=0)return'tehsil';if(m.indexOf('town city')>=0||m.indexOf('towncity')>=0)return'townCity';if(m.indexOf('qanoongo')>=0||m.indexOf('kanungo')>=0||m.indexOf('qanoon')>=0)return'qanoongoee';if(m.indexOf('mouza')>=0||m.indexOf('moza')>=0)return'mouza';if(m.indexOf('revenue circle')>=0||m.indexOf('revenuecircle')>=0)return'revenueCircle';if(m.indexOf('floor')>=0)return'floor';if(m.indexOf('property area')>=0||m.indexOf('propertyarea')>=0)return'propertyArea';if(m.indexOf('land classification')>=0||m.indexOf('landclassification')>=0)return'landClassification';if(m.indexOf('location')>=0)return'location';var o=['district','tehsil','townCity','qanoongoee','mouza','revenueCircle','floor','propertyArea','landClassification','location'];return o[idx]||'';}";
    }

    private String snapshotScript(String mode) {
        return "(function(){" + portalHelpers() +
                "var data={mode:'" + mode + "',url:location.href,title:document.title||'',bodyText:(document.body&&document.body.innerText)||'',selects:[],inputs:[],radios:[]};" +
                "var ss=Array.prototype.filter.call(document.querySelectorAll('select'),visible);" +
                "ss.forEach(function(s,idx){var o=s.options&&s.selectedIndex>=0?s.options[s.selectedIndex]:null;var opts=[];Array.prototype.forEach.call(s.options||[],function(x){opts.push({value:x.value||'',text:clean(x.text||x.innerText||'')});});data.selects.push({kind:kind(s,idx),id:s.id||'',name:s.name||'',value:s.value||'',text:o?clean(o.text):'',context:desc(s),options:opts});});" +
                "Array.prototype.forEach.call(document.querySelectorAll('input'),function(i){var type=(i.type||'').toLowerCase();if(type==='hidden'||type==='button'||type==='submit'||type==='reset')return;data.inputs.push({id:i.id||'',name:i.name||'',type:type,value:i.value||'',placeholder:i.placeholder||'',checked:!!i.checked,context:desc(i)});});" +
                "Array.prototype.forEach.call(document.querySelectorAll('input[type=radio]'),function(r){if(r.checked){data.radios.push({id:r.id||'',name:r.name||'',value:r.value||'',context:desc(r)});}});" +
                "RelianceSync.onSnapshot(JSON.stringify(data));})();";
    }

    private void captureOfficialOptions(long delayMs) {
        handler.postDelayed(() -> {
            if (officialWebView != null && officialReady) {
                officialWebView.evaluateJavascript(snapshotScript("options"), null);
            }
        }, delayMs);
    }

    private void captureOfficialValuation(long delayMs) {
        handler.postDelayed(() -> {
            if (officialWebView != null && officialReady) {
                officialWebView.evaluateJavascript(snapshotScript("valuation"), null);
            }
        }, delayMs);
    }

    private void setOfficialLandType(String type) {
        if (!officialReady) {
            officialWebView.loadUrl(OFFICIAL_DC_URL);
            return;
        }
        String t = JSONObject.quote(type == null ? "" : type);
        String js = "(function(){" + portalHelpers() +
                "var wanted=norm(" + t + ");var rs=document.querySelectorAll('input[type=radio]');var hit=null;Array.prototype.forEach.call(rs,function(r){var m=norm((r.value||'')+' '+desc(r));if(!hit&&m.indexOf(wanted)>=0)hit=r;});" +
                "if(hit){hit.checked=true;hit.click();hit.dispatchEvent(new Event('change',{bubbles:true}));try{if(window.jQuery)window.jQuery(hit).trigger('change');}catch(e){}}})();";
        officialWebView.evaluateJavascript(js, null);
        captureOfficialOptions(800);
        captureOfficialOptions(1800);
    }

    private void setOfficialOption(String field, String text) {
        if (!officialReady || field == null || text == null || text.trim().isEmpty()) return;
        String f = JSONObject.quote(field);
        String t = JSONObject.quote(text);
        String js = "(function(){" + portalHelpers() +
                "var field=" + f + ",wanted=norm(" + t + ");var ss=Array.prototype.filter.call(document.querySelectorAll('select'),visible);var target=null;ss.forEach(function(s,idx){if(!target&&kind(s,idx)===field)target=s;});" +
                "if(!target&&field==='city'){ss.forEach(function(s,idx){if(!target&&kind(s,idx)==='townCity')target=s;});}" +
                "if(target){var hit=null;Array.prototype.forEach.call(target.options||[],function(o){var tx=norm(o.text||o.innerText||'');if(!hit&&(tx===wanted||tx.indexOf(wanted)>=0||wanted.indexOf(tx)>=0))hit=o;});if(hit){target.value=hit.value;target.dispatchEvent(new Event('change',{bubbles:true}));try{if(window.jQuery)window.jQuery(target).val(hit.value).trigger('change');}catch(e){}}}})();";
        officialWebView.evaluateJavascript(js, null);
        captureOfficialOptions(700);
        captureOfficialOptions(1600);
        captureOfficialOptions(2800);
    }

    private void fetchOfficialValuation(String landArea) {
        if (!officialReady) {
            Toast.makeText(this, "Official Punjab valuation service is still loading. Please try again in a moment.", Toast.LENGTH_SHORT).show();
            officialWebView.loadUrl(OFFICIAL_DC_URL);
            return;
        }
        String area = JSONObject.quote(landArea == null ? "" : landArea);
        String js = "(function(){" + portalHelpers() +
                "var area=" + area + ";var inputs=Array.prototype.filter.call(document.querySelectorAll('input'),visible);var land=null;inputs.forEach(function(i){var m=norm(desc(i));if(!land&&m.indexOf('land area')>=0&&(i.type==='text'||i.type==='number'||!i.type))land=i;});" +
                "if(land&&area){land.value=area;land.dispatchEvent(new Event('input',{bubbles:true}));land.dispatchEvent(new Event('change',{bubbles:true}));try{if(window.jQuery)window.jQuery(land).val(area).trigger('change');}catch(e){}}" +
                "var btns=document.querySelectorAll('button,input[type=button],input[type=submit],a');var btn=null;Array.prototype.forEach.call(btns,function(b){var tx=norm((b.innerText||b.textContent||b.value||'')+' '+desc(b));if(!btn&&tx.indexOf('find land rate')>=0)btn=b;});if(btn){btn.click();}else{RelianceSync.onMessage('Find Land Rate button was not detected on the official page.');}})();";
        officialWebView.evaluateJavascript(js, null);
        captureOfficialOptions(1200);
        captureOfficialValuation(3200);
        captureOfficialValuation(6000);
    }

    private Bitmap bitmapFromDataUrl(String dataUrl) {
        try {
            String base64 = dataUrl.substring(dataUrl.indexOf(',') + 1);
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        } catch (Exception e) {
            return null;
        }
    }

    private Uri uriForFile(File file) {
        return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void openOfficialValuationDialog() {
        final Dialog dialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar_Fullscreen);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(16), dp(12), dp(16), dp(10));
        header.setBackgroundColor(Color.rgb(0, 107, 55));

        TextView title = new TextView(this);
        title.setText("Official Punjab DC Valuation");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setGravity(Gravity.START);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView help = new TextView(this);
        help.setText("Fallback official view. Complete the official form, tap Find Land Rate, then tap USE THIS VALUATION below.");
        help.setTextColor(Color.rgb(225, 245, 234));
        help.setTextSize(12);
        help.setPadding(0, dp(4), 0, 0);
        header.addView(help, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(header);

        final WebView portal = new WebView(this);
        WebSettings ps = portal.getSettings();
        ps.setJavaScriptEnabled(true);
        ps.setDomStorageEnabled(true);
        ps.setAllowFileAccess(false);
        ps.setAllowContentAccess(false);
        ps.setSupportZoom(true);
        ps.setBuiltInZoomControls(true);
        ps.setDisplayZoomControls(false);
        ps.setUseWideViewPort(true);
        ps.setLoadWithOverviewMode(true);
        ps.setTextZoom(100);

        portal.addJavascriptInterface(new PortalBridge(dialog), "ReliancePortal");
        portal.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String host = request.getUrl().getHost();
                if (host != null && (host.endsWith("punjab-zameen.gov.pk") || host.endsWith("punjab.gov.pk"))) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, request.getUrl())); } catch (Exception ignored) {}
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                try {
                    Uri uri = Uri.parse(url);
                    String host = uri.getHost();
                    if (host != null && (host.endsWith("punjab-zameen.gov.pk") || host.endsWith("punjab.gov.pk"))) return false;
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                } catch (Exception e) { return false; }
            }
        });
        portal.loadUrl(OFFICIAL_DC_URL);
        root.addView(portal, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setPadding(dp(10), dp(8), dp(10), dp(10));
        buttons.setGravity(Gravity.CENTER_VERTICAL);

        Button close = new Button(this);
        close.setText("CLOSE");
        close.setOnClickListener(v -> dialog.dismiss());
        buttons.addView(close, new LinearLayout.LayoutParams(0, dp(52), 0.34f));

        Button use = new Button(this);
        use.setText("USE THIS VALUATION");
        use.setTextColor(Color.WHITE);
        use.setBackgroundColor(Color.rgb(7, 148, 71));
        LinearLayout.LayoutParams useParams = new LinearLayout.LayoutParams(0, dp(52), 0.66f);
        useParams.setMargins(dp(8), 0, 0, 0);
        buttons.addView(use, useParams);

        use.setOnClickListener(v -> portal.evaluateJavascript("(function(){" + portalHelpers() +
                "var data={mode:'valuation',url:location.href,title:document.title||'',bodyText:(document.body&&document.body.innerText)||'',selects:[],inputs:[],radios:[]};var ss=Array.prototype.filter.call(document.querySelectorAll('select'),visible);ss.forEach(function(s,idx){var o=s.options&&s.selectedIndex>=0?s.options[s.selectedIndex]:null;var opts=[];Array.prototype.forEach.call(s.options||[],function(x){opts.push({value:x.value||'',text:clean(x.text||x.innerText||'')});});data.selects.push({kind:kind(s,idx),id:s.id||'',name:s.name||'',value:s.value||'',text:o?clean(o.text):'',context:desc(s),options:opts});});Array.prototype.forEach.call(document.querySelectorAll('input'),function(i){var type=(i.type||'').toLowerCase();if(type==='hidden'||type==='button'||type==='submit'||type==='reset')return;data.inputs.push({id:i.id||'',name:i.name||'',type:type,value:i.value||'',placeholder:i.placeholder||'',checked:!!i.checked,context:desc(i)});});Array.prototype.forEach.call(document.querySelectorAll('input[type=radio]'),function(r){if(r.checked)data.radios.push({id:r.id||'',name:r.name||'',value:r.value||'',context:desc(r)});});ReliancePortal.submitSnapshot(JSON.stringify(data));})();", null));

        root.addView(buttons);
        dialog.setContentView(root);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.WHITE));
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
        dialog.show();
    }

    private class OfficialSyncBridge {
        @JavascriptInterface
        public void onSnapshot(String json) {
            runOnUiThread(() -> {
                try {
                    JSONObject obj = new JSONObject(json);
                    String mode = obj.optString("mode", "options");
                    String quoted = JSONObject.quote(json);
                    if ("valuation".equals(mode)) {
                        webView.evaluateJavascript("window.importOfficialValuation && window.importOfficialValuation(" + quoted + ");", null);
                    } else {
                        webView.evaluateJavascript("window.receiveOfficialOptions && window.receiveOfficialOptions(" + quoted + ");", null);
                    }
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void onMessage(String message) {
            runOnUiThread(() -> webView.evaluateJavascript("window.officialSyncMessage && window.officialSyncMessage(" + JSONObject.quote(message) + ");", null));
        }
    }

    private class PortalBridge {
        private final Dialog dialog;
        PortalBridge(Dialog dialog) { this.dialog = dialog; }

        @JavascriptInterface
        public void submitSnapshot(String json) {
            runOnUiThread(() -> {
                try {
                    JSONObject obj = new JSONObject(json);
                    String body = obj.optString("bodyText", "");
                    if (body.length() < 20) {
                        Toast.makeText(MainActivity.this, "Official page data could not be read. Please try again.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    String quoted = JSONObject.quote(json);
                    webView.evaluateJavascript("window.importOfficialValuation && window.importOfficialValuation(" + quoted + ");", null);
                    if (dialog != null && dialog.isShowing()) dialog.dismiss();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Could not import official valuation. Please try again.", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    private class AppBridge {
        @JavascriptInterface
        public void initOfficialData() {
            runOnUiThread(() -> {
                if (officialReady) captureOfficialOptions(0);
                else officialWebView.loadUrl(OFFICIAL_DC_URL);
            });
        }

        @JavascriptInterface
        public void resetOfficialData() {
            runOnUiThread(() -> {
                officialReady = false;
                officialWebView.loadUrl(OFFICIAL_DC_URL);
            });
        }

        @JavascriptInterface
        public void setOfficialLandType(String type) {
            runOnUiThread(() -> MainActivity.this.setOfficialLandType(type));
        }

        @JavascriptInterface
        public void setOfficialOption(String field, String text) {
            runOnUiThread(() -> MainActivity.this.setOfficialOption(field, text));
        }

        @JavascriptInterface
        public void fetchOfficialValuation(String landArea) {
            runOnUiThread(() -> MainActivity.this.fetchOfficialValuation(landArea));
        }

        @JavascriptInterface
        public void openOfficialValuation() {
            runOnUiThread(MainActivity.this::openOfficialValuationDialog);
        }

        @JavascriptInterface
        public void openExternal(String url) {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "Unable to open link.", Toast.LENGTH_SHORT).show(); }
            });
        }

        @JavascriptInterface
        public void shareWhatsAppImage(String dataUrl) {
            runOnUiThread(() -> {
                Bitmap bitmap = bitmapFromDataUrl(dataUrl);
                if (bitmap == null) {
                    Toast.makeText(MainActivity.this, "Could not create calculation image.", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    File file = new File(getCacheDir(), "Reliance_Registry_Estimate.png");
                    try (FileOutputStream out = new FileOutputStream(file)) {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                    }
                    Uri uri = uriForFile(file);
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("image/png");
                    share.putExtra(Intent.EXTRA_STREAM, uri);
                    share.putExtra(Intent.EXTRA_TEXT, "Reliance Associates - Registry Expense Estimate");
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    share.setPackage("com.whatsapp");
                    try {
                        startActivity(share);
                    } catch (ActivityNotFoundException e) {
                        share.setPackage("com.whatsapp.w4b");
                        try { startActivity(share); }
                        catch (ActivityNotFoundException e2) {
                            share.setPackage(null);
                            startActivity(Intent.createChooser(share, "Share registry estimate"));
                        }
                    }
                } catch (IOException e) {
                    Toast.makeText(MainActivity.this, "Could not prepare image for sharing.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        if (officialWebView != null) officialWebView.destroy();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
